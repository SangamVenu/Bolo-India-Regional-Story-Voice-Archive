# Changelog

## v1.0 – Initial MVP Release
- Story and voice uploads
- Language and region tagging
