# Contributing to Bolo India

We welcome contributions of all kinds!

## How to Contribute
- Fork the repo
- Create a branch
- Submit a pull request
